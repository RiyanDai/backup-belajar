package com.dicoding.ditonton

import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        intent.removeExtra("start-paused")
        super.onCreate(savedInstanceState)
    }
}
