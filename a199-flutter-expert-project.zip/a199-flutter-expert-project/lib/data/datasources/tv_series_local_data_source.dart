import 'package:ditonton/common/exception.dart';
import 'package:ditonton/data/datasources/db/database_helper.dart';
import 'package:ditonton/data/models/tv_series_table.dart';

abstract class TvSeriesLocalDataSource {
  Future<String> insertTvWatchlist(TvSeriesTable series);
  Future<String> removeTvWatchlist(TvSeriesTable series);
  Future<TvSeriesTable?> getTvSeriesById(int id);
  Future<List<TvSeriesTable>> getWatchlistTvSeries();
}

class TvSeriesLocalDataSourceImpl implements TvSeriesLocalDataSource {
  final DatabaseHelper databaseHelper;
  TvSeriesLocalDataSourceImpl({required this.databaseHelper});
  @override
  Future<String> insertTvWatchlist(TvSeriesTable series) async {
    try {
      await databaseHelper.insertTvWatchlist(series);
      return 'Added to Watchlist';
    } catch (e) {
      throw DatabaseException(e.toString());
    }
  }

  @override
  Future<String> removeTvWatchlist(TvSeriesTable series) async {
    try {
      await databaseHelper.removeTvWatchlist(series);
      return 'Removed from Watchlist';
    } catch (e) {
      throw DatabaseException(e.toString());
    }
  }

  @override
  Future<TvSeriesTable?> getTvSeriesById(int id) async {
    final row = await databaseHelper.getTvSeriesById(id);
    return row == null ? null : TvSeriesTable.fromMap(row);
  }

  @override
  Future<List<TvSeriesTable>> getWatchlistTvSeries() async {
    final rows = await databaseHelper.getWatchlistTvSeries();
    return rows.map(TvSeriesTable.fromMap).toList();
  }
}
