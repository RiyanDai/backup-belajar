import 'dart:convert';
import 'package:ditonton/common/exception.dart';
import 'package:ditonton/data/models/tv_series_model.dart';
import 'package:ditonton/data/models/tv_series_detail_model.dart';
import 'package:http/http.dart' as http;

abstract class TvSeriesRemoteDataSource {
  Future<List<TvSeriesModel>> getOnTheAirTvSeries();
  Future<List<TvSeriesModel>> getPopularTvSeries();
  Future<List<TvSeriesModel>> getTopRatedTvSeries();
  Future<TvSeriesDetailResponse> getTvSeriesDetail(int id);
  Future<List<TvSeriesModel>> getTvSeriesRecommendations(int id);
  Future<List<TvSeriesModel>> searchTvSeries(String query);
}

class TvSeriesRemoteDataSourceImpl implements TvSeriesRemoteDataSource {
  static const apiKey = '2174d146bb9c0eab47529b2e77d6b526';
  static const baseUrl = 'https://api.themoviedb.org/3';
  final http.Client client;
  TvSeriesRemoteDataSourceImpl({required this.client});

  Future<Map<String, dynamic>> _fetch(String path, [String? query]) async {
    final uri = Uri.parse('$baseUrl/$path').replace(queryParameters: {
      'api_key': apiKey,
      if (query != null) 'query': query,
    });
    final response = await client.get(uri);
    if (response.statusCode != 200) throw ServerException();
    return json.decode(response.body) as Map<String, dynamic>;
  }

  @override
  Future<List<TvSeriesModel>> getOnTheAirTvSeries() async =>
      TvSeriesResponse.fromJson(await _fetch('tv/on_the_air')).tvSeriesList;
  @override
  Future<List<TvSeriesModel>> getPopularTvSeries() async =>
      TvSeriesResponse.fromJson(await _fetch('tv/popular')).tvSeriesList;
  @override
  Future<List<TvSeriesModel>> getTopRatedTvSeries() async =>
      TvSeriesResponse.fromJson(await _fetch('tv/top_rated')).tvSeriesList;
  @override
  Future<TvSeriesDetailResponse> getTvSeriesDetail(int id) async =>
      TvSeriesDetailResponse.fromJson(await _fetch('tv/$id'));
  @override
  Future<List<TvSeriesModel>> getTvSeriesRecommendations(int id) async =>
      TvSeriesResponse.fromJson(await _fetch('tv/$id/recommendations'))
          .tvSeriesList;
  @override
  Future<List<TvSeriesModel>> searchTvSeries(String query) async =>
      TvSeriesResponse.fromJson(await _fetch('search/tv', query)).tvSeriesList;
}
