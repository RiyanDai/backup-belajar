import 'package:ditonton/data/models/genre_model.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:equatable/equatable.dart';

class TvSeriesDetailResponse extends Equatable {
  final int id;
  final String name;
  final String? posterPath;
  final String overview;
  final double voteAverage;
  final List<GenreModel> genres;
  final int numberOfSeasons;
  final int numberOfEpisodes;
  const TvSeriesDetailResponse(
      {required this.id,
      required this.name,
      this.posterPath,
      required this.overview,
      required this.voteAverage,
      required this.genres,
      required this.numberOfSeasons,
      required this.numberOfEpisodes});
  factory TvSeriesDetailResponse.fromJson(Map<String, dynamic> json) =>
      TvSeriesDetailResponse(
          id: json['id'] as int,
          name: json['name'] as String? ?? '',
          posterPath: json['poster_path'] as String?,
          overview: json['overview'] as String? ?? '',
          voteAverage: (json['vote_average'] as num?)?.toDouble() ?? 0,
          genres: (json['genres'] as List? ?? [])
              .map((item) => GenreModel.fromJson(item as Map<String, dynamic>))
              .toList(),
          numberOfSeasons: json['number_of_seasons'] as int? ?? 0,
          numberOfEpisodes: json['number_of_episodes'] as int? ?? 0);
  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'poster_path': posterPath,
        'overview': overview,
        'vote_average': voteAverage,
        'genres': genres.map((item) => item.toJson()).toList(),
        'number_of_seasons': numberOfSeasons,
        'number_of_episodes': numberOfEpisodes
      };
  TvSeriesDetail toEntity() => TvSeriesDetail(
      id: id,
      name: name,
      posterPath: posterPath,
      overview: overview,
      voteAverage: voteAverage,
      genres: genres.map((genre) => genre.toEntity()).toList(),
      numberOfSeasons: numberOfSeasons,
      numberOfEpisodes: numberOfEpisodes);
  @override
  List<Object?> get props => [
        id,
        name,
        posterPath,
        overview,
        voteAverage,
        genres,
        numberOfSeasons,
        numberOfEpisodes
      ];
}
