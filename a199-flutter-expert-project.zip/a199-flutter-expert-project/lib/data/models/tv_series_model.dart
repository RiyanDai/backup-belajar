import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:equatable/equatable.dart';

class TvSeriesModel extends Equatable {
  final int id;
  final String name;
  final String? posterPath;
  final String overview;
  final double voteAverage;
  const TvSeriesModel(
      {required this.id,
      required this.name,
      this.posterPath,
      required this.overview,
      required this.voteAverage});
  factory TvSeriesModel.fromJson(Map<String, dynamic> json) => TvSeriesModel(
      id: json['id'] as int,
      name: json['name'] as String? ?? '',
      posterPath: json['poster_path'] as String?,
      overview: json['overview'] as String? ?? '',
      voteAverage: (json['vote_average'] as num?)?.toDouble() ?? 0);
  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'poster_path': posterPath,
        'overview': overview,
        'vote_average': voteAverage
      };
  TvSeries toEntity() => TvSeries(
      id: id,
      name: name,
      posterPath: posterPath,
      overview: overview,
      voteAverage: voteAverage);
  @override
  List<Object?> get props => [id, name, posterPath, overview, voteAverage];
}

class TvSeriesResponse extends Equatable {
  final List<TvSeriesModel> tvSeriesList;
  const TvSeriesResponse({required this.tvSeriesList});
  factory TvSeriesResponse.fromJson(Map<String, dynamic> json) =>
      TvSeriesResponse(
          tvSeriesList: (json['results'] as List)
              .map((item) =>
                  TvSeriesModel.fromJson(item as Map<String, dynamic>))
              .where((item) => item.posterPath != null)
              .toList());
  Map<String, dynamic> toJson() =>
      {'results': tvSeriesList.map((item) => item.toJson()).toList()};
  @override
  List<Object?> get props => [tvSeriesList];
}
