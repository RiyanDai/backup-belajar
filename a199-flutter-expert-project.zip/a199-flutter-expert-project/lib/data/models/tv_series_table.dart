import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:equatable/equatable.dart';

class TvSeriesTable extends Equatable {
  final int id;
  final String name;
  final String? posterPath;
  final String overview;
  const TvSeriesTable(
      {required this.id,
      required this.name,
      this.posterPath,
      required this.overview});
  factory TvSeriesTable.fromEntity(TvSeriesDetail detail) => TvSeriesTable(
      id: detail.id,
      name: detail.name,
      posterPath: detail.posterPath,
      overview: detail.overview);
  factory TvSeriesTable.fromMap(Map<String, dynamic> map) => TvSeriesTable(
      id: map['id'] as int,
      name: map['title'] as String? ?? '',
      posterPath: map['posterPath'] as String?,
      overview: map['overview'] as String? ?? '');
  Map<String, dynamic> toJson() =>
      {'id': id, 'title': name, 'posterPath': posterPath, 'overview': overview};
  TvSeries toEntity() => TvSeries(
      id: id,
      name: name,
      posterPath: posterPath,
      overview: overview,
      voteAverage: 0);
  @override
  List<Object?> get props => [id, name, posterPath, overview];
}
