import 'dart:io';
import 'package:dartz/dartz.dart';
import 'package:ditonton/common/exception.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/data/datasources/tv_series_remote_data_source.dart';
import 'package:ditonton/data/datasources/tv_series_local_data_source.dart';
import 'package:ditonton/data/models/tv_series_model.dart';
import 'package:ditonton/data/models/tv_series_table.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:ditonton/domain/repositories/tv_series_repository.dart';

class TvSeriesRepositoryImpl implements TvSeriesRepository {
  final TvSeriesRemoteDataSource remoteDataSource;
  final TvSeriesLocalDataSource localDataSource;
  TvSeriesRepositoryImpl(
      {required this.remoteDataSource, required this.localDataSource});

  Future<Either<Failure, T>> _remote<T>(Future<T> Function() action) async {
    try {
      return Right(await action());
    } on ServerException {
      return Left(ServerFailure(''));
    } on SocketException {
      return Left(ConnectionFailure('Failed to connect to the network'));
    }
  }

  List<TvSeries> _entities(List<TvSeriesModel> items) =>
      items.map((item) => item.toEntity()).toList();
  @override
  Future<Either<Failure, List<TvSeries>>> getOnTheAirTvSeries() => _remote(
      () async => _entities(await remoteDataSource.getOnTheAirTvSeries()));
  @override
  Future<Either<Failure, List<TvSeries>>> getPopularTvSeries() => _remote(
      () async => _entities(await remoteDataSource.getPopularTvSeries()));
  @override
  Future<Either<Failure, List<TvSeries>>> getTopRatedTvSeries() => _remote(
      () async => _entities(await remoteDataSource.getTopRatedTvSeries()));
  @override
  Future<Either<Failure, List<TvSeries>>> getTvSeriesRecommendations(int id) =>
      _remote(() async =>
          _entities(await remoteDataSource.getTvSeriesRecommendations(id)));
  @override
  Future<Either<Failure, List<TvSeries>>> searchTvSeries(String query) =>
      _remote(
          () async => _entities(await remoteDataSource.searchTvSeries(query)));
  @override
  Future<Either<Failure, TvSeriesDetail>> getTvSeriesDetail(int id) => _remote(
      () async => (await remoteDataSource.getTvSeriesDetail(id)).toEntity());
  @override
  Future<Either<Failure, String>> saveTvSeriesWatchlist(
      TvSeriesDetail series) async {
    try {
      return Right(await localDataSource
          .insertTvWatchlist(TvSeriesTable.fromEntity(series)));
    } on DatabaseException catch (e) {
      return Left(DatabaseFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, String>> removeTvSeriesWatchlist(
      TvSeriesDetail series) async {
    try {
      return Right(await localDataSource
          .removeTvWatchlist(TvSeriesTable.fromEntity(series)));
    } on DatabaseException catch (e) {
      return Left(DatabaseFailure(e.message));
    }
  }

  @override
  Future<bool> isAddedToWatchlist(int id) async =>
      (await localDataSource.getTvSeriesById(id)) != null;
  @override
  Future<Either<Failure, List<TvSeries>>> getWatchlistTvSeries() async {
    try {
      return Right((await localDataSource.getWatchlistTvSeries())
          .map((row) => row.toEntity())
          .toList());
    } on DatabaseException catch (e) {
      return Left(DatabaseFailure(e.message));
    }
  }
}
