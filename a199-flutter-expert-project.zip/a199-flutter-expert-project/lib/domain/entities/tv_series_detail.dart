import 'package:ditonton/domain/entities/genre.dart';
import 'package:equatable/equatable.dart';

class TvSeriesDetail extends Equatable {
  final int id;
  final String name;
  final String? posterPath;
  final String overview;
  final double voteAverage;
  final List<Genre> genres;
  final int numberOfSeasons;
  final int numberOfEpisodes;
  const TvSeriesDetail(
      {required this.id,
      required this.name,
      this.posterPath,
      required this.overview,
      required this.voteAverage,
      required this.genres,
      required this.numberOfSeasons,
      required this.numberOfEpisodes});
  @override
  List<Object?> get props => [
        id,
        name,
        posterPath,
        overview,
        voteAverage,
        genres,
        numberOfSeasons,
        numberOfEpisodes
      ];
}
