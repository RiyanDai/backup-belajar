import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/presentation/pages/tv_series_list_page.dart';
import 'package:ditonton/presentation/pages/tv_series_search_page.dart';
import 'package:ditonton/presentation/pages/tv_series_watchlist_page.dart';
import 'package:ditonton/presentation/provider/tv_list_notifier.dart';
import 'package:ditonton/presentation/widgets/tv_card_list.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomeTvSeriesPage extends StatefulWidget {
  static const ROUTE_NAME = '/home-tv-series';
  const HomeTvSeriesPage({super.key});
  @override
  State<HomeTvSeriesPage> createState() => _HomeTvSeriesPageState();
}

class _HomeTvSeriesPageState extends State<HomeTvSeriesPage> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      final notifier = context.read<TvListNotifier>();
      notifier.fetchOnTheAirTvSeries();
      notifier.fetchPopularTvSeries();
      notifier.fetchTopRatedTvSeries();
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('TV Series'), actions: [
          IconButton(
              icon: const Icon(Icons.search),
              onPressed: () =>
                  Navigator.pushNamed(context, TvSeriesSearchPage.ROUTE_NAME)),
          IconButton(
              icon: const Icon(Icons.bookmark),
              onPressed: () => Navigator.pushNamed(
                  context, TvSeriesWatchlistPage.ROUTE_NAME)),
        ]),
        body: Consumer<TvListNotifier>(
            builder: (context, data, _) => ListView(children: [
                  _section(
                      context,
                      'On The Air',
                      TvSeriesListPage.onTheAir,
                      data.onTheAirState,
                      data.onTheAirMessage,
                      data.onTheAirTvSeries),
                  _section(
                      context,
                      'Popular',
                      TvSeriesListPage.popular,
                      data.popularState,
                      data.popularMessage,
                      data.popularTvSeries),
                  _section(
                      context,
                      'Top Rated',
                      TvSeriesListPage.topRated,
                      data.topRatedState,
                      data.topRatedMessage,
                      data.topRatedTvSeries),
                ])),
      );

  Widget _section(BuildContext context, String title, String category,
          RequestState state, String message, List<TvSeries> items) =>
      Column(children: [
        ListTile(
            title: Text(title),
            trailing: const Text('See More'),
            onTap: () => Navigator.pushNamed(
                context, TvSeriesListPage.ROUTE_NAME,
                arguments: category)),
        if (state == RequestState.Loading)
          const CircularProgressIndicator()
        else if (state == RequestState.Error)
          Text(message)
        else if (state == RequestState.Loaded)
          TvPosterList(items),
      ]);
}
