import 'package:cached_network_image/cached_network_image.dart';
import 'package:ditonton/common/constants.dart';
import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/presentation/provider/tv_detail_notifier.dart';
import 'package:ditonton/presentation/widgets/tv_card_list.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TvSeriesDetailPage extends StatefulWidget {
  static const ROUTE_NAME = '/detail-tv-series';
  final int id;
  const TvSeriesDetailPage({required this.id, super.key});
  @override
  State<TvSeriesDetailPage> createState() => _TvSeriesDetailPageState();
}

class _TvSeriesDetailPageState extends State<TvSeriesDetailPage> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      context.read<TvDetailNotifier>().fetchTvSeriesDetail(widget.id);
      context.read<TvDetailNotifier>().loadWatchlistStatus(widget.id);
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('TV Series Detail')),
        body: Consumer<TvDetailNotifier>(builder: (context, data, _) {
          if (data.detailState == RequestState.Loading ||
              data.detailState == RequestState.Empty) {
            return const Center(child: CircularProgressIndicator());
          }
          if (data.detailState == RequestState.Error)
            return Center(child: Text(data.message));
          final detail = data.tvSeries!;
          return ListView(padding: const EdgeInsets.all(16), children: [
            SizedBox(
                height: 260,
                child: CachedNetworkImage(
                    imageUrl: '$BASE_IMAGE_URL${detail.posterPath}',
                    fit: BoxFit.contain,
                    errorWidget: (_, __, ___) =>
                        const Icon(Icons.broken_image))),
            Text(detail.name, style: kHeading5),
            FilledButton.icon(
              icon: Icon(data.isAddedToWatchlist ? Icons.check : Icons.add),
              label: const Text('Watchlist'),
              onPressed: () async {
                if (data.isAddedToWatchlist) {
                  await data.removeFromWatchlist(detail);
                } else {
                  await data.addWatchlist(detail);
                }
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(data.watchlistMessage)));
              },
            ),
            Text(detail.genres.map((genre) => genre.name).join(', ')),
            Text(
                '${detail.numberOfSeasons} seasons • ${detail.numberOfEpisodes} episodes'),
            Row(children: [
              const Icon(Icons.star, color: kMikadoYellow),
              Text('${detail.voteAverage}')
            ]),
            Text('Overview', style: kHeading6),
            Text(detail.overview),
            const SizedBox(height: 16),
            Text('Recommendations', style: kHeading6),
            if (data.recommendationState == RequestState.Loading)
              const Center(child: CircularProgressIndicator())
            else if (data.recommendationState == RequestState.Error)
              Text(data.message)
            else if (data.recommendationState == RequestState.Loaded)
              ...data.recommendations.map((series) => TvCard(series)),
          ]);
        }),
      );
}
