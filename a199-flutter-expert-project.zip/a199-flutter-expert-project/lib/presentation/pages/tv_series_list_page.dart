import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/presentation/provider/tv_list_notifier.dart';
import 'package:ditonton/presentation/widgets/tv_card_list.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TvSeriesListPage extends StatefulWidget {
  static const ROUTE_NAME = '/tv-series-list';
  static const onTheAir = 'on-the-air';
  static const popular = 'popular';
  static const topRated = 'top-rated';
  final String category;
  const TvSeriesListPage({required this.category, super.key});
  @override
  State<TvSeriesListPage> createState() => _TvSeriesListPageState();
}

class _TvSeriesListPageState extends State<TvSeriesListPage> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      final notifier = context.read<TvListNotifier>();
      switch (widget.category) {
        case TvSeriesListPage.onTheAir:
          notifier.fetchOnTheAirTvSeries();
          break;
        case TvSeriesListPage.popular:
          notifier.fetchPopularTvSeries();
          break;
        case TvSeriesListPage.topRated:
          notifier.fetchTopRatedTvSeries();
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
            title: Text(widget.category == TvSeriesListPage.onTheAir
                ? 'On The Air TV Series'
                : widget.category == TvSeriesListPage.popular
                    ? 'Popular TV Series'
                    : 'Top Rated TV Series')),
        body: Consumer<TvListNotifier>(builder: (context, data, _) {
          final state = widget.category == TvSeriesListPage.onTheAir
              ? data.onTheAirState
              : widget.category == TvSeriesListPage.popular
                  ? data.popularState
                  : data.topRatedState;
          final message = widget.category == TvSeriesListPage.onTheAir
              ? data.onTheAirMessage
              : widget.category == TvSeriesListPage.popular
                  ? data.popularMessage
                  : data.topRatedMessage;
          final items = widget.category == TvSeriesListPage.onTheAir
              ? data.onTheAirTvSeries
              : widget.category == TvSeriesListPage.popular
                  ? data.popularTvSeries
                  : data.topRatedTvSeries;
          if (state == RequestState.Loading)
            return const Center(child: CircularProgressIndicator());
          if (state == RequestState.Error) return Center(child: Text(message));
          return ListView.builder(
              itemCount: items.length, itemBuilder: (_, i) => TvCard(items[i]));
        }),
      );
}
