import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/presentation/provider/tv_search_notifier.dart';
import 'package:ditonton/presentation/widgets/tv_card_list.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TvSeriesSearchPage extends StatelessWidget {
  static const ROUTE_NAME = '/search-tv-series';
  const TvSeriesSearchPage({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Search TV Series')),
        body: Column(children: [
          Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                decoration: const InputDecoration(
                    hintText: 'Search title', prefixIcon: Icon(Icons.search)),
                textInputAction: TextInputAction.search,
                onSubmitted: (query) =>
                    context.read<TvSearchNotifier>().fetchTvSeriesSearch(query),
              )),
          Expanded(child: Consumer<TvSearchNotifier>(builder: (_, data, __) {
            if (data.state == RequestState.Loading)
              return const Center(child: CircularProgressIndicator());
            if (data.state == RequestState.Error)
              return Center(child: Text(data.message));
            return ListView.builder(
                itemCount: data.searchResult.length,
                itemBuilder: (_, i) => TvCard(data.searchResult[i]));
          })),
        ]),
      );
}
