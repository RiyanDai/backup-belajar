import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/common/utils.dart';
import 'package:ditonton/presentation/provider/tv_watchlist_notifier.dart';
import 'package:ditonton/presentation/widgets/tv_card_list.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class TvSeriesWatchlistPage extends StatefulWidget {
  static const ROUTE_NAME = '/watchlist-tv-series';
  const TvSeriesWatchlistPage({super.key});
  @override
  State<TvSeriesWatchlistPage> createState() => _TvSeriesWatchlistPageState();
}

class _TvSeriesWatchlistPageState extends State<TvSeriesWatchlistPage>
    with RouteAware {
  @override
  void initState() {
    super.initState();
    Future.microtask(
        () => context.read<TvWatchlistNotifier>().fetchWatchlistTvSeries());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    routeObserver.subscribe(this, ModalRoute.of(context)!);
  }

  @override
  void didPopNext() =>
      context.read<TvWatchlistNotifier>().fetchWatchlistTvSeries();
  @override
  void dispose() {
    routeObserver.unsubscribe(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('TV Series Watchlist')),
        body: Consumer<TvWatchlistNotifier>(builder: (_, data, __) {
          if (data.state == RequestState.Loading)
            return const Center(child: CircularProgressIndicator());
          if (data.state == RequestState.Error)
            return Center(child: Text(data.message));
          return ListView.builder(
              itemCount: data.tvSeries.length,
              itemBuilder: (_, i) => TvCard(data.tvSeries[i]));
        }),
      );
}
