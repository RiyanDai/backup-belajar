import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:ditonton/domain/usecases/get_tv_series_detail.dart';
import 'package:ditonton/domain/usecases/get_tv_series_recommendations.dart';
import 'package:ditonton/domain/usecases/get_tv_series_watchlist_status.dart';
import 'package:ditonton/domain/usecases/save_tv_series_watchlist.dart';
import 'package:ditonton/domain/usecases/remove_tv_series_watchlist.dart';
import 'package:flutter/foundation.dart';

class TvDetailNotifier extends ChangeNotifier {
  final GetTvSeriesDetail getTvSeriesDetail;
  final GetTvSeriesRecommendations getTvSeriesRecommendations;
  final GetTvSeriesWatchlistStatus getTvSeriesWatchlistStatus;
  final SaveTvSeriesWatchlist saveTvSeriesWatchlist;
  final RemoveTvSeriesWatchlist removeTvSeriesWatchlist;

  TvDetailNotifier(
      {required this.getTvSeriesDetail,
      required this.getTvSeriesRecommendations,
      required this.getTvSeriesWatchlistStatus,
      required this.saveTvSeriesWatchlist,
      required this.removeTvSeriesWatchlist});

  TvSeriesDetail? tvSeries;
  List<TvSeries> recommendations = [];
  RequestState detailState = RequestState.Empty;
  RequestState recommendationState = RequestState.Empty;
  String message = '';
  String watchlistMessage = '';
  bool isAddedToWatchlist = false;

  Future<void> fetchTvSeriesDetail(int id) async {
    detailState = RequestState.Loading;
    recommendationState = RequestState.Empty;
    tvSeries = null;
    recommendations = [];
    notifyListeners();
    final result = await getTvSeriesDetail.execute(id);
    result.fold((failure) {
      detailState = RequestState.Error;
      message = failure.message;
    }, (detail) {
      detailState = RequestState.Loaded;
      tvSeries = detail;
      message = '';
    });
    notifyListeners();
    if (detailState == RequestState.Loaded) {
      recommendationState = RequestState.Loading;
      notifyListeners();
      final result = await getTvSeriesRecommendations.execute(id);
      result.fold((failure) {
        recommendationState = RequestState.Error;
        message = failure.message;
      }, (items) {
        recommendationState = RequestState.Loaded;
        recommendations = items;
      });
      notifyListeners();
    }
  }

  Future<void> loadWatchlistStatus(int id) async {
    isAddedToWatchlist = await getTvSeriesWatchlistStatus.execute(id);
    notifyListeners();
  }

  Future<void> addWatchlist(TvSeriesDetail detail) async {
    final result = await saveTvSeriesWatchlist.execute(detail);
    result.fold((failure) => watchlistMessage = failure.message,
        (success) => watchlistMessage = success);
    await loadWatchlistStatus(detail.id);
  }

  Future<void> removeFromWatchlist(TvSeriesDetail detail) async {
    final result = await removeTvSeriesWatchlist.execute(detail);
    result.fold((failure) => watchlistMessage = failure.message,
        (success) => watchlistMessage = success);
    await loadWatchlistStatus(detail.id);
  }
}
