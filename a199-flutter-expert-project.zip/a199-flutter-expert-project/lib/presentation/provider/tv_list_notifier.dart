import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/usecases/get_on_the_air_tv_series.dart';
import 'package:ditonton/domain/usecases/get_popular_tv_series.dart';
import 'package:ditonton/domain/usecases/get_top_rated_tv_series.dart';
import 'package:flutter/foundation.dart';

class TvListNotifier extends ChangeNotifier {
  final GetOnTheAirTvSeries getOnTheAirTvSeries;
  final GetPopularTvSeries getPopularTvSeries;
  final GetTopRatedTvSeries getTopRatedTvSeries;

  TvListNotifier(
      {required this.getOnTheAirTvSeries,
      required this.getPopularTvSeries,
      required this.getTopRatedTvSeries});

  RequestState onTheAirState = RequestState.Empty;
  RequestState popularState = RequestState.Empty;
  RequestState topRatedState = RequestState.Empty;
  String onTheAirMessage = '';
  String popularMessage = '';
  String topRatedMessage = '';
  List<TvSeries> onTheAirTvSeries = [];
  List<TvSeries> popularTvSeries = [];
  List<TvSeries> topRatedTvSeries = [];

  Future<void> fetchOnTheAirTvSeries() async {
    onTheAirState = RequestState.Loading;
    notifyListeners();
    final result = await getOnTheAirTvSeries.execute();
    result.fold((failure) {
      onTheAirState = RequestState.Error;
      onTheAirMessage = failure.message;
    }, (items) {
      onTheAirState = RequestState.Loaded;
      onTheAirTvSeries = items;
    });
    notifyListeners();
  }

  Future<void> fetchPopularTvSeries() async {
    popularState = RequestState.Loading;
    notifyListeners();
    final result = await getPopularTvSeries.execute();
    result.fold((failure) {
      popularState = RequestState.Error;
      popularMessage = failure.message;
    }, (items) {
      popularState = RequestState.Loaded;
      popularTvSeries = items;
    });
    notifyListeners();
  }

  Future<void> fetchTopRatedTvSeries() async {
    topRatedState = RequestState.Loading;
    notifyListeners();
    final result = await getTopRatedTvSeries.execute();
    result.fold((failure) {
      topRatedState = RequestState.Error;
      topRatedMessage = failure.message;
    }, (items) {
      topRatedState = RequestState.Loaded;
      topRatedTvSeries = items;
    });
    notifyListeners();
  }
}
