import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/usecases/search_tv_series.dart';
import 'package:flutter/foundation.dart';

class TvSearchNotifier extends ChangeNotifier {
  final SearchTvSeries searchTvSeries;
  TvSearchNotifier({required this.searchTvSeries});

  RequestState state = RequestState.Empty;
  List<TvSeries> searchResult = [];
  String message = '';

  Future<void> fetchTvSeriesSearch(String query) async {
    state = RequestState.Loading;
    notifyListeners();
    final result = await searchTvSeries.execute(query);
    result.fold((failure) {
      state = RequestState.Error;
      message = failure.message;
      searchResult = [];
    }, (items) {
      state = RequestState.Loaded;
      searchResult = items;
      message = '';
    });
    notifyListeners();
  }
}
