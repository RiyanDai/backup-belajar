import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/usecases/get_watchlist_tv_series.dart';
import 'package:flutter/foundation.dart';

class TvWatchlistNotifier extends ChangeNotifier {
  final GetWatchlistTvSeries getWatchlistTvSeries;
  TvWatchlistNotifier({required this.getWatchlistTvSeries});

  RequestState state = RequestState.Empty;
  String message = '';
  List<TvSeries> tvSeries = [];

  Future<void> fetchWatchlistTvSeries() async {
    state = RequestState.Loading;
    notifyListeners();
    final result = await getWatchlistTvSeries.execute();
    result.fold((failure) {
      state = RequestState.Error;
      message = failure.message;
      tvSeries = [];
    }, (items) {
      state = RequestState.Loaded;
      tvSeries = items;
      message = '';
    });
    notifyListeners();
  }
}
