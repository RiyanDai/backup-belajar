import 'package:cached_network_image/cached_network_image.dart';
import 'package:ditonton/common/constants.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/presentation/pages/tv_series_detail_page.dart';
import 'package:flutter/material.dart';

class TvCard extends StatelessWidget {
  final TvSeries tvSeries;
  const TvCard(this.tvSeries, {super.key});

  @override
  Widget build(BuildContext context) => Card(
        child: ListTile(
          onTap: () => Navigator.pushNamed(
              context, TvSeriesDetailPage.ROUTE_NAME,
              arguments: tvSeries.id),
          leading: SizedBox(
              width: 60,
              child: CachedNetworkImage(
                imageUrl: '$BASE_IMAGE_URL${tvSeries.posterPath}',
                errorWidget: (_, __, ___) => const Icon(Icons.broken_image),
              )),
          title:
              Text(tvSeries.name, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(tvSeries.overview,
              maxLines: 2, overflow: TextOverflow.ellipsis),
        ),
      );
}

class TvPosterList extends StatelessWidget {
  final List<TvSeries> tvSeries;
  const TvPosterList(this.tvSeries, {super.key});

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 190,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: tvSeries.length,
          itemBuilder: (context, index) {
            final item = tvSeries[index];
            return InkWell(
              onTap: () => Navigator.pushNamed(
                  context, TvSeriesDetailPage.ROUTE_NAME,
                  arguments: item.id),
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: SizedBox(
                    width: 115,
                    child: CachedNetworkImage(
                      imageUrl: '$BASE_IMAGE_URL${item.posterPath}',
                      fit: BoxFit.cover,
                      errorWidget: (_, __, ___) =>
                          const Icon(Icons.broken_image),
                    )),
              ),
            );
          },
        ),
      );
}
