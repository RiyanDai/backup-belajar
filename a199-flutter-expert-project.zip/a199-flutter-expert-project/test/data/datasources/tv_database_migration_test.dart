import 'dart:io';
import 'package:ditonton/data/datasources/db/database_helper.dart';
import 'package:ditonton/data/models/movie_table.dart';
import 'package:ditonton/data/models/tv_series_table.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;

  test('upgrading existing movie DB retains films and persists TV watchlist', () async {
    final path = '${await getDatabasesPath()}/ditonton.db';
    final file = File(path);
    if (await file.exists()) await file.delete();
    final oldDb = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('CREATE TABLE watchlist (id INTEGER PRIMARY KEY, title TEXT, overview TEXT, posterPath TEXT)');
    });
    await oldDb.insert('watchlist', {'id': 42, 'title': 'Film', 'overview': 'Movie', 'posterPath': '/movie'});
    await oldDb.close();

    final helper = DatabaseHelper();
    final movie = await helper.getMovieById(42);
    expect(movie?['title'], 'Film');
    final tv = TvSeriesTable(id: 42, name: 'Serial', overview: 'Show', posterPath: '/tv');
    await helper.insertTvWatchlist(tv);
    expect((await helper.getTvSeriesById(42))?['title'], 'Serial');
    expect((await helper.getMovieById(42))?['title'], 'Film');
    final db = await helper.database;
    await db!.close();
    final reopened = await openDatabase(path);
    expect((await reopened.query('watchlist', where: 'id = ?', whereArgs: [42])).single['title'], 'Film');
    expect((await reopened.query('tv_watchlist', where: 'id = ?', whereArgs: [42])).single['title'], 'Serial');
    await reopened.close();
    await file.delete();
  });
}
