import 'package:ditonton/common/exception.dart';
import 'package:ditonton/data/datasources/db/database_helper.dart';
import 'package:ditonton/data/datasources/tv_series_local_data_source.dart';
import 'package:ditonton/data/models/tv_series_table.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

class FakeDb extends Mock implements DatabaseHelper {
  final rows = <int, Map<String, dynamic>>{};
  bool fail = false;
  @override
  Future<int> insertTvWatchlist(TvSeriesTable series) async {
    if (fail) throw Exception('disk');
    rows[series.id] = series.toJson();
    return series.id;
  }

  @override
  Future<int> removeTvWatchlist(TvSeriesTable series) async {
    if (fail) throw Exception('disk');
    rows.remove(series.id);
    return 1;
  }

  @override
  Future<Map<String, dynamic>?> getTvSeriesById(int id) async => rows[id];
  @override
  Future<List<Map<String, dynamic>>> getWatchlistTvSeries() async =>
      rows.values.toList();
}

void main() {
  test('inserts and restores a series through database helper', () async {
    final db = FakeDb();
    final source = TvSeriesLocalDataSourceImpl(databaseHelper: db);
    const series = TvSeriesTable(
        id: 3, name: 'Alpha', overview: 'Story', posterPath: '/a');
    expect(await source.insertTvWatchlist(series), 'Added to Watchlist');
    expect(db.rows[3]!['title'], 'Alpha');
    expect(await source.getTvSeriesById(3), series);
    expect(await source.getWatchlistTvSeries(), [series]);
    expect(await source.removeTvWatchlist(series), 'Removed from Watchlist');
    expect(await source.getTvSeriesById(3), null);
  });
  test('wraps write errors as DatabaseException', () async {
    final db = FakeDb()..fail = true;
    final source = TvSeriesLocalDataSourceImpl(databaseHelper: db);
    const series = TvSeriesTable(id: 3, name: 'Alpha', overview: 'Story');
    expect(source.insertTvWatchlist(series), throwsA(isA<DatabaseException>()));
    expect(source.removeTvWatchlist(series), throwsA(isA<DatabaseException>()));
  });
}
