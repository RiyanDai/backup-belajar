import 'package:ditonton/data/datasources/tv_series_remote_data_source.dart';
import 'package:ditonton/common/exception.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

void main() {
  test('on the air requests TV endpoint and parses results', () async {
    final source =
        TvSeriesRemoteDataSourceImpl(client: MockClient((request) async {
      expect(request.url.path, '/3/tv/on_the_air');
      return http.Response(
          '{"results":[{"id":1,"name":"Alpha","poster_path":"/a","vote_average":8}]}',
          200);
    }));
    expect((await source.getOnTheAirTvSeries()).single.name, 'Alpha');
  });
  test('search escapes query parameter', () async {
    final source =
        TvSeriesRemoteDataSourceImpl(client: MockClient((request) async {
      expect(request.url.path, '/3/search/tv');
      expect(request.url.queryParameters['query'], 'a & b');
      return http.Response('{"results":[]}', 200);
    }));
    expect(await source.searchTvSeries('a & b'), isEmpty);
  });
  test('server errors throw ServerException', () async {
    final source = TvSeriesRemoteDataSourceImpl(
        client: MockClient((_) async => http.Response('', 500)));
    expect(source.getPopularTvSeries(), throwsA(isA<ServerException>()));
  });
  test('detail parses seasons and episodes', () async {
    final source =
        TvSeriesRemoteDataSourceImpl(client: MockClient((request) async {
      expect(request.url.path, '/3/tv/7');
      return http.Response(
          '{"id":7,"name":"Alpha","genres":[],"number_of_seasons":2,"number_of_episodes":9}',
          200);
    }));
    expect((await source.getTvSeriesDetail(7)).numberOfEpisodes, 9);
  });
}
