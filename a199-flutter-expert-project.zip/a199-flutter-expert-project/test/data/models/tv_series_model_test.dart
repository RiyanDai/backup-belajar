import 'package:ditonton/data/models/tv_series_model.dart';
import 'package:ditonton/data/models/tv_series_detail_model.dart';
import 'package:ditonton/data/models/tv_series_table.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('TV response maps name and filters items with no poster', () {
    final response = TvSeriesResponse.fromJson({
      'results': [
        {
          'id': 1,
          'name': 'Alpha',
          'poster_path': '/a',
          'overview': 'Story',
          'vote_average': 8
        },
        {'id': 2, 'name': 'Beta', 'poster_path': null}
      ]
    });
    expect(response.tvSeriesList.map((e) => e.name), ['Alpha']);
    expect(response.tvSeriesList.single.toEntity().voteAverage, 8.0);
  });

  test('detail maps genres, seasons and episodes', () {
    final detail = TvSeriesDetailResponse.fromJson({
      'id': 1,
      'name': 'Alpha',
      'overview': 'Story',
      'poster_path': '/a',
      'vote_average': 8,
      'genres': [
        {'id': 3, 'name': 'Drama'}
      ],
      'number_of_seasons': 2,
      'number_of_episodes': 12
    }).toEntity();
    expect(detail.genres.single.name, 'Drama');
    expect(detail.numberOfSeasons, 2);
    expect(detail.numberOfEpisodes, 12);
  });

  test('watchlist uses title database column and restores name', () {
    final row = TvSeriesTable.fromMap(
        {'id': 1, 'title': 'Alpha', 'overview': 'Story', 'posterPath': '/a'});
    expect(row.toJson()['title'], 'Alpha');
    expect(row.toEntity().name, 'Alpha');
  });
}
