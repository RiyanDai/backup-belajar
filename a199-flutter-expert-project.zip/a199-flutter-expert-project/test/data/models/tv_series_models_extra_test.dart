import 'package:ditonton/data/models/tv_series_detail_model.dart';
import 'package:ditonton/data/models/tv_series_model.dart';
import 'package:ditonton/data/models/tv_series_table.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('series model defaults nullable API fields and serializes them', () {
    final model = TvSeriesModel.fromJson({
      'id': 10,
      'name': null,
      'poster_path': null,
      'overview': null,
      'vote_average': null
    });
    expect(model.name, '');
    expect(model.posterPath, isNull);
    expect(model.overview, '');
    expect(model.voteAverage, 0);
    expect(model.toEntity().posterPath, isNull);
    expect(model.toJson(), {
      'id': 10,
      'name': '',
      'poster_path': null,
      'overview': '',
      'vote_average': 0.0,
    });
  });

  test('response keeps only poster-bearing results and roundtrips JSON', () {
    final response = TvSeriesResponse.fromJson({
      'results': [
        {
          'id': 1,
          'name': 'One',
          'poster_path': '/one',
          'overview': 'Plot',
          'vote_average': 7
        },
        {
          'id': 2,
          'name': 'Two',
          'poster_path': null,
          'overview': null,
          'vote_average': null
        },
      ]
    });
    expect(response.tvSeriesList.map((item) => item.id), [1]);
    expect(TvSeriesResponse.fromJson(response.toJson()), response);
  });

  test('detail defaults missing and null fields, converts and roundtrips', () {
    final model = TvSeriesDetailResponse.fromJson({
      'id': 8,
      'name': null,
      'poster_path': null,
      'overview': null,
      'vote_average': null,
      'genres': null,
      'number_of_seasons': null,
      'number_of_episodes': null,
    });
    final entity = model.toEntity();
    expect(entity.name, '');
    expect(entity.posterPath, isNull);
    expect(entity.overview, '');
    expect(entity.voteAverage, 0);
    expect(entity.genres, isEmpty);
    expect(entity.numberOfSeasons, 0);
    expect(entity.numberOfEpisodes, 0);
    expect(TvSeriesDetailResponse.fromJson(model.toJson()), model);
  });

  test('detail serializes genres and numeric rating without losing values', () {
    final model = TvSeriesDetailResponse.fromJson({
      'id': 9,
      'name': 'Nine',
      'poster_path': '/nine',
      'overview': 'Plot',
      'vote_average': 9,
      'genres': [
        {'id': 3, 'name': 'Drama'}
      ],
      'number_of_seasons': 3,
      'number_of_episodes': 18,
    });
    expect(model.toJson()['genres'], [
      {'id': 3, 'name': 'Drama'}
    ]);
    expect(model.toEntity().genres.single.name, 'Drama');
    expect(model.toEntity().voteAverage, 9.0);
    expect(TvSeriesDetailResponse.fromJson(model.toJson()), model);
  });

  test(
      'watchlist table converts detail, preserves nullable poster and database fields',
      () {
    const detail = TvSeriesDetail(
      id: 8,
      name: 'Eight',
      overview: 'Story',
      voteAverage: 7,
      genres: [],
      numberOfSeasons: 2,
      numberOfEpisodes: 10,
    );
    final table = TvSeriesTable.fromEntity(detail);
    expect(table.toJson(),
        {'id': 8, 'title': 'Eight', 'posterPath': null, 'overview': 'Story'});
    expect(TvSeriesTable.fromMap(table.toJson()), table);
    expect(table.toEntity().voteAverage, 0);
    final nullable = TvSeriesTable.fromMap(
        {'id': 3, 'title': null, 'posterPath': null, 'overview': null});
    expect(nullable.name, '');
    expect(nullable.overview, '');
    expect(nullable.posterPath, isNull);
  });
}
