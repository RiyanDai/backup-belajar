import 'dart:io';
import 'package:dartz/dartz.dart';
import 'package:ditonton/common/exception.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/data/datasources/tv_series_remote_data_source.dart';
import 'package:ditonton/data/datasources/tv_series_local_data_source.dart';
import 'package:ditonton/data/models/tv_series_model.dart';
import 'package:ditonton/data/models/tv_series_detail_model.dart';
import 'package:ditonton/data/models/tv_series_table.dart';
import 'package:ditonton/data/repositories/tv_series_repository_impl.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:flutter_test/flutter_test.dart';

class RemoteStub implements TvSeriesRemoteDataSource {
  Object? error;
  final model = TvSeriesModel(
      id: 7,
      name: 'Alpha',
      posterPath: '/a',
      overview: 'Story',
      voteAverage: 8);
  @override
  Future<List<TvSeriesModel>> getOnTheAirTvSeries() async {
    if (error != null) throw error!;
    return [model];
  }

  @override
  Future<List<TvSeriesModel>> getPopularTvSeries() => getOnTheAirTvSeries();
  @override
  Future<List<TvSeriesModel>> getTopRatedTvSeries() => getOnTheAirTvSeries();
  @override
  Future<List<TvSeriesModel>> getTvSeriesRecommendations(int id) =>
      getOnTheAirTvSeries();
  @override
  Future<List<TvSeriesModel>> searchTvSeries(String query) =>
      getOnTheAirTvSeries();
  @override
  Future<TvSeriesDetailResponse> getTvSeriesDetail(int id) async =>
      TvSeriesDetailResponse.fromJson(
          {'id': id, 'name': 'Alpha', 'genres': []});
}

class LocalStub implements TvSeriesLocalDataSource {
  Object? error;
  TvSeriesTable? saved;
  @override
  Future<String> insertTvWatchlist(TvSeriesTable series) async {
    if (error != null) throw error!;
    saved = series;
    return 'Added to Watchlist';
  }

  @override
  Future<String> removeTvWatchlist(TvSeriesTable series) async {
    if (error != null) throw error!;
    saved = null;
    return 'Removed from Watchlist';
  }

  @override
  Future<TvSeriesTable?> getTvSeriesById(int id) async => saved;
  @override
  Future<List<TvSeriesTable>> getWatchlistTvSeries() async =>
      saved == null ? [] : [saved!];
}

void main() {
  late RemoteStub remote;
  late LocalStub local;
  late TvSeriesRepositoryImpl repo;
  setUp(() {
    remote = RemoteStub();
    local = LocalStub();
    repo = TvSeriesRepositoryImpl(
        remoteDataSource: remote, localDataSource: local);
  });
  test('list maps models to entities', () async {
    final result = await repo.getOnTheAirTvSeries();
    expect(result.getOrElse(() => []), [remote.model.toEntity()]);
    expect((await repo.getPopularTvSeries()).getOrElse(() => []),
        [remote.model.toEntity()]);
    expect((await repo.getTopRatedTvSeries()).getOrElse(() => []),
        [remote.model.toEntity()]);
    expect((await repo.searchTvSeries('Alpha')).getOrElse(() => []),
        [remote.model.toEntity()]);
    expect((await repo.getTvSeriesRecommendations(7)).getOrElse(() => []),
        [remote.model.toEntity()]);
  });
  test('server and network errors map to failures', () async {
    remote.error = ServerException();
    expect(await repo.getPopularTvSeries(), Left(ServerFailure('')));
    remote.error = const SocketException('offline');
    expect(await repo.getOnTheAirTvSeries(),
        Left(ConnectionFailure('Failed to connect to the network')));
  });
  test('watchlist round trip persists title and status', () async {
    final detail = TvSeriesDetail(
        id: 7,
        name: 'Alpha',
        overview: 'Story',
        genres: [],
        numberOfSeasons: 2,
        numberOfEpisodes: 3,
        voteAverage: 8);
    expect(await repo.saveTvSeriesWatchlist(detail),
        const Right('Added to Watchlist'));
    expect(local.saved!.toJson()['title'], 'Alpha');
    expect(await repo.isAddedToWatchlist(7), true);
    expect((await repo.getWatchlistTvSeries()).getOrElse(() => []).single.name,
        'Alpha');
    expect(await repo.removeTvSeriesWatchlist(detail),
        const Right('Removed from Watchlist'));
    expect(await repo.isAddedToWatchlist(7), false);
  });
  test('database errors map to DatabaseFailure', () async {
    local.error = DatabaseException('disk');
    final detail = TvSeriesDetail(
        id: 7,
        name: 'Alpha',
        overview: '',
        genres: [],
        numberOfSeasons: 0,
        numberOfEpisodes: 0,
        voteAverage: 0);
    expect(await repo.saveTvSeriesWatchlist(detail),
        Left(DatabaseFailure('disk')));
  });
}
