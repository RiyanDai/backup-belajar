import 'package:dartz/dartz.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:ditonton/domain/repositories/tv_series_repository.dart';
import 'package:ditonton/domain/usecases/get_on_the_air_tv_series.dart';
import 'package:ditonton/domain/usecases/get_popular_tv_series.dart';
import 'package:ditonton/domain/usecases/get_top_rated_tv_series.dart';
import 'package:ditonton/domain/usecases/get_tv_series_detail.dart';
import 'package:ditonton/domain/usecases/get_tv_series_recommendations.dart';
import 'package:ditonton/domain/usecases/get_tv_series_watchlist_status.dart';
import 'package:ditonton/domain/usecases/get_watchlist_tv_series.dart';
import 'package:ditonton/domain/usecases/remove_tv_series_watchlist.dart';
import 'package:ditonton/domain/usecases/save_tv_series_watchlist.dart';
import 'package:ditonton/domain/usecases/search_tv_series.dart';
import 'package:flutter_test/flutter_test.dart';

const series =
    TvSeries(id: 12, name: 'Series', overview: 'Story', voteAverage: 8);
const detail = TvSeriesDetail(
  id: 12,
  name: 'Series',
  overview: 'Story',
  voteAverage: 8,
  genres: [],
  numberOfSeasons: 1,
  numberOfEpisodes: 8,
);

class RecordingRepository implements TvSeriesRepository {
  String? call;
  Object? argument;
  Either<Failure, List<TvSeries>> listResult = const Right([series]);
  Either<Failure, TvSeriesDetail> detailResult = const Right(detail);
  Either<Failure, String> writeResult = const Right('written');
  bool statusResult = true;

  @override
  Future<Either<Failure, List<TvSeries>>> getOnTheAirTvSeries() async {
    call = 'on air';
    return listResult;
  }

  @override
  Future<Either<Failure, List<TvSeries>>> getPopularTvSeries() async {
    call = 'popular';
    return listResult;
  }

  @override
  Future<Either<Failure, List<TvSeries>>> getTopRatedTvSeries() async {
    call = 'top rated';
    return listResult;
  }

  @override
  Future<Either<Failure, TvSeriesDetail>> getTvSeriesDetail(int id) async {
    call = 'detail';
    argument = id;
    return detailResult;
  }

  @override
  Future<Either<Failure, List<TvSeries>>> getTvSeriesRecommendations(
      int id) async {
    call = 'recommendations';
    argument = id;
    return listResult;
  }

  @override
  Future<Either<Failure, List<TvSeries>>> searchTvSeries(String query) async {
    call = 'search';
    argument = query;
    return listResult;
  }

  @override
  Future<Either<Failure, List<TvSeries>>> getWatchlistTvSeries() async {
    call = 'watchlist';
    return listResult;
  }

  @override
  Future<Either<Failure, String>> saveTvSeriesWatchlist(
      TvSeriesDetail series) async {
    call = 'save';
    argument = series;
    return writeResult;
  }

  @override
  Future<Either<Failure, String>> removeTvSeriesWatchlist(
      TvSeriesDetail series) async {
    call = 'remove';
    argument = series;
    return writeResult;
  }

  @override
  Future<bool> isAddedToWatchlist(int id) async {
    call = 'status';
    argument = id;
    return statusResult;
  }
}

void main() {
  late RecordingRepository repository;
  setUp(() => repository = RecordingRepository());

  test('list use cases delegate to the correct repository methods', () async {
    for (final (name, action)
        in <(String, Future<Either<Failure, List<TvSeries>>> Function())>[
      ('on air', () => GetOnTheAirTvSeries(repository).execute()),
      ('popular', () => GetPopularTvSeries(repository).execute()),
      ('top rated', () => GetTopRatedTvSeries(repository).execute()),
      ('watchlist', () => GetWatchlistTvSeries(repository).execute()),
    ]) {
      expect(await action(), const Right<Failure, List<TvSeries>>([series]));
      expect(repository.call, name);
    }
  });

  test('list use cases preserve repository failures', () async {
    repository.listResult = Left(ServerFailure('offline'));
    expect(
        await GetOnTheAirTvSeries(repository).execute(), repository.listResult);
    expect(
        await GetPopularTvSeries(repository).execute(), repository.listResult);
    expect(
        await GetTopRatedTvSeries(repository).execute(), repository.listResult);
    expect(await GetWatchlistTvSeries(repository).execute(),
        repository.listResult);
  });

  test('detail and recommendations forward the series id', () async {
    expect(await GetTvSeriesDetail(repository).execute(12),
        const Right<Failure, TvSeriesDetail>(detail));
    expect(repository.call, 'detail');
    expect(repository.argument, 12);
    expect(await GetTvSeriesRecommendations(repository).execute(13),
        const Right<Failure, List<TvSeries>>([series]));
    expect(repository.call, 'recommendations');
    expect(repository.argument, 13);
  });

  test('detail and recommendations preserve failures', () async {
    repository.detailResult = Left(ServerFailure('missing detail'));
    repository.listResult = Left(ServerFailure('missing recommendations'));
    expect(await GetTvSeriesDetail(repository).execute(12),
        repository.detailResult);
    expect(await GetTvSeriesRecommendations(repository).execute(12),
        repository.listResult);
  });

  test('search forwards exact query and preserves both results and errors',
      () async {
    expect(await SearchTvSeries(repository).execute('a b'),
        const Right<Failure, List<TvSeries>>([series]));
    expect(repository.call, 'search');
    expect(repository.argument, 'a b');
    repository.listResult = Left(ServerFailure('offline'));
    expect(await SearchTvSeries(repository).execute('other'),
        repository.listResult);
  });

  test('save and remove forward exact detail and return repository result',
      () async {
    expect(await SaveTvSeriesWatchlist(repository).execute(detail),
        const Right<Failure, String>('written'));
    expect(repository.call, 'save');
    expect(repository.argument, detail);
    repository.writeResult = Left(DatabaseFailure('write failed'));
    expect(await RemoveTvSeriesWatchlist(repository).execute(detail),
        repository.writeResult);
    expect(repository.call, 'remove');
    expect(repository.argument, detail);
  });

  test('status delegates id and returns true or false unchanged', () async {
    expect(await GetTvSeriesWatchlistStatus(repository).execute(12), isTrue);
    expect(repository.call, 'status');
    expect(repository.argument, 12);
    repository.statusResult = false;
    expect(await GetTvSeriesWatchlistStatus(repository).execute(13), isFalse);
    expect(repository.argument, 13);
  });
}
