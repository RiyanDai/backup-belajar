import 'package:dartz/dartz.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/domain/entities/movie.dart';
import 'package:ditonton/domain/repositories/movie_repository.dart';
import 'package:ditonton/domain/usecases/get_now_playing_movies.dart';
import 'package:ditonton/domain/usecases/get_popular_movies.dart';
import 'package:ditonton/domain/usecases/get_top_rated_movies.dart';
import 'package:ditonton/presentation/pages/home_movie_page.dart';
import 'package:ditonton/presentation/provider/movie_list_notifier.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

class _NowPlaying implements GetNowPlayingMovies {
  @override
  MovieRepository get repository => throw UnimplementedError();
  @override
  Future<Either<Failure, List<Movie>>> execute() async => Right(<Movie>[]);
}
class _Popular implements GetPopularMovies {
  @override
  MovieRepository get repository => throw UnimplementedError();
  @override
  Future<Either<Failure, List<Movie>>> execute() async => Right(<Movie>[]);
}
class _TopRated implements GetTopRatedMovies {
  @override
  MovieRepository get repository => throw UnimplementedError();
  @override
  Future<Either<Failure, List<Movie>>> execute() async => Right(<Movie>[]);
}

void main() {
  testWidgets('Movie drawer exposes TV Series navigation', (tester) async {
    final nowPlaying = _NowPlaying();
    final popular = _Popular();
    final topRated = _TopRated();
    await tester.pumpWidget(ChangeNotifierProvider(
      create: (_) => MovieListNotifier(
        getNowPlayingMovies: nowPlaying,
        getPopularMovies: popular,
        getTopRatedMovies: topRated,
      ),
      child: MaterialApp(home: HomeMoviePage()),
    ));
    await tester.tap(find.byTooltip('Open navigation menu'));
    await tester.pump();
    expect(find.text('TV Series'), findsOneWidget);
  });
}
