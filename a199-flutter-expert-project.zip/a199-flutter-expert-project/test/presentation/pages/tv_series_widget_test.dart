import 'package:dartz/dartz.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:ditonton/domain/repositories/tv_series_repository.dart';
import 'package:ditonton/domain/usecases/get_on_the_air_tv_series.dart';
import 'package:ditonton/domain/usecases/get_popular_tv_series.dart';
import 'package:ditonton/domain/usecases/get_top_rated_tv_series.dart';
import 'package:ditonton/domain/usecases/get_tv_series_detail.dart';
import 'package:ditonton/domain/usecases/get_tv_series_recommendations.dart';
import 'package:ditonton/domain/usecases/get_tv_series_watchlist_status.dart';
import 'package:ditonton/domain/usecases/get_watchlist_tv_series.dart';
import 'package:ditonton/domain/usecases/remove_tv_series_watchlist.dart';
import 'package:ditonton/domain/usecases/save_tv_series_watchlist.dart';
import 'package:ditonton/domain/usecases/search_tv_series.dart';
import 'package:ditonton/presentation/pages/home_tv_series_page.dart';
import 'package:ditonton/presentation/pages/tv_series_detail_page.dart';
import 'package:ditonton/presentation/pages/tv_series_list_page.dart';
import 'package:ditonton/presentation/pages/tv_series_search_page.dart';
import 'package:ditonton/presentation/pages/tv_series_watchlist_page.dart';
import 'package:ditonton/presentation/provider/tv_detail_notifier.dart';
import 'package:ditonton/presentation/provider/tv_list_notifier.dart';
import 'package:ditonton/presentation/provider/tv_search_notifier.dart';
import 'package:ditonton/presentation/provider/tv_watchlist_notifier.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

const series = TvSeries(
    id: 42,
    name: 'Example Show',
    overview: 'A sample overview',
    voteAverage: 8.5);
const detail = TvSeriesDetail(
    id: 42,
    name: 'Example Show',
    overview: 'A sample overview',
    voteAverage: 8.5,
    genres: [],
    numberOfSeasons: 2,
    numberOfEpisodes: 20);

class _Repository implements TvSeriesRepository {
  bool fail = false;
  bool recommendationFails = false;
  bool saved = false;
  int onTheAirCalls = 0,
      popularCalls = 0,
      topRatedCalls = 0,
      watchlistCalls = 0;
  String lastQuery = '';
  int? lastDetailId;
  Either<Failure, List<TvSeries>> get items =>
      fail ? Left(ServerFailure('Network unavailable')) : const Right([series]);
  @override
  Future<Either<Failure, List<TvSeries>>> getOnTheAirTvSeries() async {
    onTheAirCalls++;
    return items;
  }

  @override
  Future<Either<Failure, List<TvSeries>>> getPopularTvSeries() async {
    popularCalls++;
    return items;
  }

  @override
  Future<Either<Failure, List<TvSeries>>> getTopRatedTvSeries() async {
    topRatedCalls++;
    return items;
  }

  @override
  Future<Either<Failure, TvSeriesDetail>> getTvSeriesDetail(int id) async {
    lastDetailId = id;
    return fail
        ? Left(ServerFailure('Detail unavailable'))
        : const Right(detail);
  }

  @override
  Future<Either<Failure, List<TvSeries>>> getTvSeriesRecommendations(
          int id) async =>
      recommendationFails
          ? Left(ServerFailure('Recommendations unavailable'))
          : const Right([series]);
  @override
  Future<Either<Failure, List<TvSeries>>> searchTvSeries(String query) async {
    lastQuery = query;
    return items;
  }

  @override
  Future<Either<Failure, List<TvSeries>>> getWatchlistTvSeries() async {
    watchlistCalls++;
    return items;
  }

  @override
  Future<bool> isAddedToWatchlist(int id) async => saved;
  @override
  Future<Either<Failure, String>> saveTvSeriesWatchlist(
      TvSeriesDetail series) async {
    saved = true;
    return const Right('Added to watchlist');
  }

  @override
  Future<Either<Failure, String>> removeTvSeriesWatchlist(
      TvSeriesDetail series) async {
    saved = false;
    return const Right('Removed from watchlist');
  }
}

Widget _app(_Repository repo, Widget home) => MultiProvider(
      providers: [
        ChangeNotifierProvider(
            create: (_) => TvListNotifier(
                getOnTheAirTvSeries: GetOnTheAirTvSeries(repo),
                getPopularTvSeries: GetPopularTvSeries(repo),
                getTopRatedTvSeries: GetTopRatedTvSeries(repo))),
        ChangeNotifierProvider(
            create: (_) =>
                TvSearchNotifier(searchTvSeries: SearchTvSeries(repo))),
        ChangeNotifierProvider(
            create: (_) => TvWatchlistNotifier(
                getWatchlistTvSeries: GetWatchlistTvSeries(repo))),
        ChangeNotifierProvider(
            create: (_) => TvDetailNotifier(
                getTvSeriesDetail: GetTvSeriesDetail(repo),
                getTvSeriesRecommendations: GetTvSeriesRecommendations(repo),
                getTvSeriesWatchlistStatus: GetTvSeriesWatchlistStatus(repo),
                saveTvSeriesWatchlist: SaveTvSeriesWatchlist(repo),
                removeTvSeriesWatchlist: RemoveTvSeriesWatchlist(repo))),
      ],
      child: MaterialApp(home: home, routes: {
        TvSeriesListPage.ROUTE_NAME: (context) => TvSeriesListPage(
            category: ModalRoute.of(context)!.settings.arguments! as String),
        TvSeriesDetailPage.ROUTE_NAME: (context) => TvSeriesDetailPage(
            id: ModalRoute.of(context)!.settings.arguments! as int),
        TvSeriesSearchPage.ROUTE_NAME: (_) => const TvSeriesSearchPage(),
        TvSeriesWatchlistPage.ROUTE_NAME: (_) => const TvSeriesWatchlistPage(),
      }),
    );

void main() {
  testWidgets(
      'home loads three categories and See More opens the selected list',
      (tester) async {
    final repo = _Repository();
    await tester.pumpWidget(_app(repo, const HomeTvSeriesPage()));
    await tester.pumpAndSettle();
    expect(repo.onTheAirCalls, 1);
    expect(repo.popularCalls, 1);
    expect(repo.topRatedCalls, 1);
    expect(find.text('On The Air'), findsOneWidget);
    expect(find.text('Popular'), findsOneWidget);
    expect(find.text('Top Rated'), findsOneWidget);
    await tester.tap(find.text('See More').first);
    await tester.pumpAndSettle();
    expect(find.text('On The Air TV Series'), findsOneWidget);
    expect(find.text('Example Show'), findsOneWidget);
    expect(repo.onTheAirCalls, 2);
    await tester.tap(find.text('Example Show'));
    await tester.pumpAndSettle();
    expect(repo.lastDetailId, 42);
    expect(find.text('TV Series Detail'), findsOneWidget);
  });

  testWidgets(
      'home reports category errors and opens popular and top-rated lists',
      (tester) async {
    final repo = _Repository()..fail = true;
    await tester.pumpWidget(_app(repo, const HomeTvSeriesPage()));
    await tester.pumpAndSettle();
    expect(find.text('Network unavailable'), findsNWidgets(3));
    for (final category in ['Popular TV Series', 'Top Rated TV Series']) {
      await tester.tap(
          find.text('See More').at(category == 'Popular TV Series' ? 1 : 2));
      await tester.pumpAndSettle();
      expect(find.text(category), findsOneWidget);
      expect(find.text('Network unavailable'), findsOneWidget);
      await tester.pageBack();
      await tester.pumpAndSettle();
    }
  });

  testWidgets('home search submits query and opens result detail',
      (tester) async {
    final repo = _Repository();
    await tester.pumpWidget(_app(repo, const HomeTvSeriesPage()));
    await tester.pumpAndSettle();
    await tester.tap(find.byIcon(Icons.search));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextField), 'Example');
    await tester.testTextInput.receiveAction(TextInputAction.search);
    await tester.pumpAndSettle();
    expect(repo.lastQuery, 'Example');
    expect(find.text('Example Show'), findsOneWidget);
    await tester.tap(find.text('Example Show'));
    await tester.pumpAndSettle();
    expect(repo.lastDetailId, 42);
  });

  testWidgets('search shows a request error', (tester) async {
    final repo = _Repository()..fail = true;
    await tester.pumpWidget(_app(repo, const TvSeriesSearchPage()));
    await tester.enterText(find.byType(TextField), 'missing');
    await tester.testTextInput.receiveAction(TextInputAction.search);
    await tester.pumpAndSettle();
    expect(find.text('Network unavailable'), findsOneWidget);
  });

  testWidgets('home bookmark opens watchlist and its cards', (tester) async {
    final repo = _Repository();
    await tester.pumpWidget(_app(repo, const HomeTvSeriesPage()));
    await tester.pumpAndSettle();
    await tester.tap(find.byIcon(Icons.bookmark));
    await tester.pumpAndSettle();
    expect(repo.watchlistCalls, 1);
    expect(find.text('TV Series Watchlist'), findsOneWidget);
    expect(find.text('Example Show'), findsOneWidget);
  });

  testWidgets('watchlist shows repository error', (tester) async {
    await tester.pumpWidget(
        _app(_Repository()..fail = true, const TvSeriesWatchlistPage()));
    await tester.pumpAndSettle();
    expect(find.text('Network unavailable'), findsOneWidget);
  });

  testWidgets('detail renders metadata, recommendations and toggles watchlist',
      (tester) async {
    final repo = _Repository();
    await tester.pumpWidget(_app(repo, const TvSeriesDetailPage(id: 42)));
    await tester.pumpAndSettle();
    expect(find.text('2 seasons • 20 episodes'), findsOneWidget);
    expect(find.text('Overview'), findsOneWidget);
    expect(find.text('Recommendations'), findsOneWidget);
    expect(find.text('Example Show'), findsNWidgets(2));
    await tester.tap(find.text('Watchlist'));
    await tester.pumpAndSettle();
    expect(repo.saved, true);
    expect(find.byIcon(Icons.check), findsOneWidget);
    expect(find.text('Added to watchlist'), findsOneWidget);
    await tester.tap(find.text('Watchlist'));
    await tester.pumpAndSettle();
    expect(repo.saved, false);
    expect(find.byIcon(Icons.add), findsOneWidget);
  });

  testWidgets('detail shows request failure', (tester) async {
    final repo = _Repository()..fail = true;
    await tester.pumpWidget(_app(repo, const TvSeriesDetailPage(id: 42)));
    await tester.pumpAndSettle();
    expect(find.text('Detail unavailable'), findsOneWidget);
  });

  testWidgets('detail shows recommendations failure while retaining detail',
      (tester) async {
    final repo = _Repository()..recommendationFails = true;
    await tester.pumpWidget(_app(repo, const TvSeriesDetailPage(id: 42)));
    await tester.pumpAndSettle();
    expect(find.text('Example Show'), findsOneWidget);
    expect(find.text('Recommendations unavailable'), findsOneWidget);
  });
}
