import 'package:dartz/dartz.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/usecases/get_tv_series_detail.dart';
import 'package:ditonton/domain/usecases/get_tv_series_recommendations.dart';
import 'package:ditonton/domain/usecases/get_tv_series_watchlist_status.dart';
import 'package:ditonton/domain/usecases/save_tv_series_watchlist.dart';
import 'package:ditonton/domain/usecases/remove_tv_series_watchlist.dart';
import 'package:ditonton/presentation/provider/tv_detail_notifier.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

class DetailMock extends Mock implements GetTvSeriesDetail {
  @override
  Future<Either<Failure, TvSeriesDetail>> execute(int id) async =>
      Left(ServerFailure('offline'));
}
class RecommendationsMock extends Mock implements GetTvSeriesRecommendations {
  int calls = 0;
  @override
  Future<Either<Failure, List<TvSeries>>> execute(int id) async {
    calls++;
    return Right(<TvSeries>[]);
  }
}
class StatusMock extends Mock implements GetTvSeriesWatchlistStatus {}
class SaveMock extends Mock implements SaveTvSeriesWatchlist {}
class RemoveMock extends Mock implements RemoveTvSeriesWatchlist {}

void main() {
  test('detail error surfaces failure without loading recommendations', () async {
    final detail = DetailMock();
    final recommendations = RecommendationsMock();
    final notifier = TvDetailNotifier(
        getTvSeriesDetail: detail,
        getTvSeriesRecommendations: recommendations,
        getTvSeriesWatchlistStatus: StatusMock(),
        saveTvSeriesWatchlist: SaveMock(),
        removeTvSeriesWatchlist: RemoveMock());
    await notifier.fetchTvSeriesDetail(7);
    expect(notifier.detailState, RequestState.Error);
    expect(notifier.message, 'offline');
    expect(recommendations.calls, 0);
  });
}
