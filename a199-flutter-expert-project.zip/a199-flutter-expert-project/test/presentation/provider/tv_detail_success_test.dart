import 'dart:async';

import 'package:dartz/dartz.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/entities/tv_series_detail.dart';
import 'package:ditonton/domain/repositories/tv_series_repository.dart';
import 'package:mockito/mockito.dart';
import 'package:ditonton/domain/usecases/get_tv_series_detail.dart';
import 'package:ditonton/domain/usecases/get_tv_series_recommendations.dart';
import 'package:ditonton/domain/usecases/get_tv_series_watchlist_status.dart';
import 'package:ditonton/domain/usecases/remove_tv_series_watchlist.dart';
import 'package:ditonton/domain/usecases/save_tv_series_watchlist.dart';
import 'package:ditonton/presentation/provider/tv_detail_notifier.dart';
import 'package:flutter_test/flutter_test.dart';

const sampleDetail = TvSeriesDetail(
  id: 42,
  name: 'Sample',
  posterPath: '/sample.jpg',
  overview: 'Story',
  voteAverage: 8.5,
  genres: [],
  numberOfSeasons: 2,
  numberOfEpisodes: 12,
);
const sampleRecommendation = TvSeries(
  id: 43,
  name: 'Next',
  posterPath: '/next.jpg',
  overview: 'More',
  voteAverage: 7,
);

class DetailStub extends GetTvSeriesDetail {
  DetailStub() : super(_UnusedRepository());
  Either<Failure, TvSeriesDetail> result = const Right(sampleDetail);
  Completer<Either<Failure, TvSeriesDetail>>? pending;
  int? requestedId;
  @override
  Future<Either<Failure, TvSeriesDetail>> execute(int id) {
    requestedId = id;
    return pending?.future ?? Future.value(result);
  }
}

class RecommendationsStub extends GetTvSeriesRecommendations {
  RecommendationsStub() : super(_UnusedRepository());
  Either<Failure, List<TvSeries>> result = const Right([sampleRecommendation]);
  Completer<Either<Failure, List<TvSeries>>>? pending;
  int? requestedId;
  @override
  Future<Either<Failure, List<TvSeries>>> execute(int id) {
    requestedId = id;
    return pending?.future ?? Future.value(result);
  }
}

class StatusStub extends GetTvSeriesWatchlistStatus {
  StatusStub() : super(_UnusedRepository());
  bool value = false;
  int? requestedId;
  @override
  Future<bool> execute(int id) async {
    requestedId = id;
    return value;
  }
}

class SaveStub extends SaveTvSeriesWatchlist {
  SaveStub() : super(_UnusedRepository());
  Either<Failure, String> result = const Right('saved');
  TvSeriesDetail? received;
  @override
  Future<Either<Failure, String>> execute(TvSeriesDetail series) async {
    received = series;
    return result;
  }
}

class RemoveStub extends RemoveTvSeriesWatchlist {
  RemoveStub() : super(_UnusedRepository());
  Either<Failure, String> result = const Right('removed');
  TvSeriesDetail? received;
  @override
  Future<Either<Failure, String>> execute(TvSeriesDetail series) async {
    received = series;
    return result;
  }
}

// These use cases override execute; no repository call is expected.
class _UnusedRepository extends Mock implements TvSeriesRepository {}

void main() {
  late DetailStub detail;
  late RecommendationsStub recommendations;
  late StatusStub status;
  late SaveStub save;
  late RemoveStub remove;
  late TvDetailNotifier notifier;

  setUp(() {
    detail = DetailStub();
    recommendations = RecommendationsStub();
    status = StatusStub();
    save = SaveStub();
    remove = RemoveStub();
    notifier = TvDetailNotifier(
      getTvSeriesDetail: detail,
      getTvSeriesRecommendations: recommendations,
      getTvSeriesWatchlistStatus: status,
      saveTvSeriesWatchlist: save,
      removeTvSeriesWatchlist: remove,
    );
  });

  test('detail and recommendations expose loading then loaded states',
      () async {
    detail.pending = Completer();
    recommendations.pending = Completer();
    final observed = <(RequestState, RequestState)>[];
    notifier.addListener(() =>
        observed.add((notifier.detailState, notifier.recommendationState)));
    final request = notifier.fetchTvSeriesDetail(42);
    expect(observed, [(RequestState.Loading, RequestState.Empty)]);
    detail.pending!.complete(const Right(sampleDetail));
    await Future<void>.delayed(Duration.zero);
    expect(notifier.tvSeries, sampleDetail);
    expect(notifier.recommendations, isEmpty);
    expect(observed.last, (RequestState.Loaded, RequestState.Loading));
    recommendations.pending!.complete(const Right([sampleRecommendation]));
    await request;
    expect(observed.last, (RequestState.Loaded, RequestState.Loaded));
    expect(notifier.recommendations, [sampleRecommendation]);
    expect(detail.requestedId, 42);
    expect(recommendations.requestedId, 42);
  });

  test('recommendation error retains loaded detail and reports failure',
      () async {
    recommendations.result = Left(ServerFailure('recommendations unavailable'));
    await notifier.fetchTvSeriesDetail(42);
    expect(notifier.detailState, RequestState.Loaded);
    expect(notifier.tvSeries, sampleDetail);
    expect(notifier.recommendationState, RequestState.Error);
    expect(notifier.message, 'recommendations unavailable');
    expect(notifier.recommendations, isEmpty);
  });

  test('another fetch clears previous detail and recommendations while loading',
      () async {
    await notifier.fetchTvSeriesDetail(42);
    detail.pending = Completer();
    final request = notifier.fetchTvSeriesDetail(99);
    expect(notifier.detailState, RequestState.Loading);
    expect(notifier.recommendationState, RequestState.Empty);
    expect(notifier.tvSeries, isNull);
    expect(notifier.recommendations, isEmpty);
    detail.pending!.complete(Left(ServerFailure('detail unavailable')));
    await request;
    expect(notifier.detailState, RequestState.Error);
    expect(notifier.message, 'detail unavailable');
    expect(recommendations.requestedId, 42);
  });

  test('watchlist status loads the requested id', () async {
    status.value = true;
    await notifier.loadWatchlistStatus(42);
    expect(status.requestedId, 42);
    expect(notifier.isAddedToWatchlist, isTrue);
  });

  test('saving and removing refresh watchlist state and messages', () async {
    status.value = true;
    await notifier.addWatchlist(sampleDetail);
    expect(save.received, sampleDetail);
    expect(notifier.watchlistMessage, 'saved');
    expect(notifier.isAddedToWatchlist, isTrue);
    status.value = false;
    await notifier.removeFromWatchlist(sampleDetail);
    expect(remove.received, sampleDetail);
    expect(notifier.watchlistMessage, 'removed');
    expect(notifier.isAddedToWatchlist, isFalse);
    expect(status.requestedId, 42);
  });

  test('save failure reports error and still reloads status', () async {
    save.result = Left(DatabaseFailure('cannot save'));
    await notifier.addWatchlist(sampleDetail);
    expect(notifier.watchlistMessage, 'cannot save');
    expect(status.requestedId, 42);
  });

  test('remove failure reports error and still reloads status', () async {
    status.value = true;
    remove.result = Left(DatabaseFailure('cannot remove'));
    await notifier.removeFromWatchlist(sampleDetail);
    expect(notifier.watchlistMessage, 'cannot remove');
    expect(notifier.isAddedToWatchlist, isTrue);
    expect(status.requestedId, 42);
  });
}
