import 'package:dartz/dartz.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/usecases/get_on_the_air_tv_series.dart';
import 'package:ditonton/domain/usecases/get_popular_tv_series.dart';
import 'package:ditonton/domain/usecases/get_top_rated_tv_series.dart';
import 'package:ditonton/domain/usecases/search_tv_series.dart';
import 'package:ditonton/presentation/provider/tv_list_notifier.dart';
import 'package:ditonton/presentation/provider/tv_search_notifier.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

class OnAirMock extends Mock implements GetOnTheAirTvSeries {
  int calls = 0;
  @override
  Future<Either<Failure, List<TvSeries>>> execute() async {
    calls++;
    return Right(<TvSeries>[]);
  }
}
class PopularMock extends Mock implements GetPopularTvSeries {
  int calls = 0;
  bool fail = false;
  @override
  Future<Either<Failure, List<TvSeries>>> execute() async {
    calls++;
    return fail ? Left(ServerFailure('Gagal')) : Right(<TvSeries>[]);
  }
}
class TopRatedMock extends Mock implements GetTopRatedTvSeries {
  int calls = 0;
  @override
  Future<Either<Failure, List<TvSeries>>> execute() async {
    calls++;
    return Right(<TvSeries>[]);
  }
}
class SearchMock extends Mock implements SearchTvSeries {
  final queries = <String>[];
  @override
  Future<Either<Failure, List<TvSeries>>> execute(String query) async {
    queries.add(query);
    return query == 'error' ? Left(ServerFailure('Jaringan gagal')) : Right(<TvSeries>[]);
  }
}

void main() {
  late OnAirMock onAir;
  late PopularMock popular;
  late TopRatedMock topRated;
  late SearchMock search;
  setUp(() {
    onAir = OnAirMock();
    popular = PopularMock();
    topRated = TopRatedMock();
    search = SearchMock();
  });

  test('each homepage category loads from its own use case', () async {
    final notifier = TvListNotifier(
        getOnTheAirTvSeries: onAir,
        getPopularTvSeries: popular,
        getTopRatedTvSeries: topRated);
    await notifier.fetchOnTheAirTvSeries();
    await notifier.fetchPopularTvSeries();
    await notifier.fetchTopRatedTvSeries();
    expect(notifier.onTheAirState, RequestState.Loaded);
    expect(notifier.popularState, RequestState.Loaded);
    expect(notifier.topRatedState, RequestState.Loaded);
    expect(onAir.calls, 1);
    expect(popular.calls, 1);
    expect(topRated.calls, 1);
  });

  test('failed category request exposes error message', () async {
    popular.fail = true;
    final notifier = TvListNotifier(
        getOnTheAirTvSeries: onAir,
        getPopularTvSeries: popular,
        getTopRatedTvSeries: topRated);
    await notifier.fetchPopularTvSeries();
    expect(notifier.popularState, RequestState.Error);
    expect(notifier.popularMessage, 'Gagal');
  });

  test('search submits query to API use case and reports failure', () async {
    final notifier = TvSearchNotifier(searchTvSeries: search);
    await notifier.fetchTvSeriesSearch('drama');
    expect(notifier.state, RequestState.Loaded);
    expect(search.queries, ['drama']);
    await notifier.fetchTvSeriesSearch('error');
    expect(notifier.state, RequestState.Error);
    expect(notifier.message, 'Jaringan gagal');
  });
}
