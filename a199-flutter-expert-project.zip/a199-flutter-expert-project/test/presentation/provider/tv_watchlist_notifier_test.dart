import 'package:dartz/dartz.dart';
import 'package:ditonton/common/failure.dart';
import 'package:ditonton/common/state_enum.dart';
import 'package:ditonton/domain/entities/tv_series.dart';
import 'package:ditonton/domain/usecases/get_watchlist_tv_series.dart';
import 'package:ditonton/presentation/provider/tv_watchlist_notifier.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';

class WatchlistMock extends Mock implements GetWatchlistTvSeries {
  bool fail = false;
  @override
  Future<Either<Failure, List<TvSeries>>> execute() async =>
      fail ? Left(ServerFailure('offline')) : Right(<TvSeries>[]);
}

void main() {
  test('watchlist exposes loaded results and failure', () async {
    final usecase = WatchlistMock();
    final notifier = TvWatchlistNotifier(getWatchlistTvSeries: usecase);
    await notifier.fetchWatchlistTvSeries();
    expect(notifier.state, RequestState.Loaded);
    expect(notifier.tvSeries, isEmpty);
    usecase.fail = true;
    await notifier.fetchWatchlistTvSeries();
    expect(notifier.state, RequestState.Error);
    expect(notifier.message, 'offline');
  });
}
